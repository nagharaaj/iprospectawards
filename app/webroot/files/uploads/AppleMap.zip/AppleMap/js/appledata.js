var res = {
	"GlobalData": {
		"US": {
			"Country": "US",
			"Orders": "1,709",
			"Total": "$473,238.53"
		},
		"AU": {
			"Country": "AU",
			"Orders": 95,
			"Total": "$35,527.14"
		},
		"DE": {
			"Country": "DE",
			"Orders": 447,
			"Total": "$134,468.11"
		},
		"CN": {
			"Country": "CN",
			"Orders": 16,
			"Total": "$6,139.17"
		},
		"HU": {
			"Country": "HU",
			"Orders": 10,
			"Total": "$28.53"
		},
		"SE": {
			"Country": "SE",
			"Orders": 30,
			"Total": "$6,563.40"
		},
		"UK": {
			"Country": "UK",
			"Orders": "1,016",
			"Total": "$294,572.11"
		},
		"BR": {
			"Country": "BR",
			"Orders": 222,
			"Total": "$100,535.62"
		},
		"NL": {
			"Country": "NL",
			"Orders": 92,
			"Total": "$23,383.30"
		},
		"CH": {
			"Country": "CH",
			"Orders": 16,
			"Total": "$6,789.90"
		},
		"KR": {
			"Country": "KR",
			"Orders": 6,
			"Total": "$1,905.30"
		},
		"PL": {
			"Country": "PL",
			"Orders": 2,
			"Total": "$767.69"
		},
		"FR": {
			"Country": "FR",
			"Orders": 88,
			"Total": "$24,078.45"
		},
		"IT": {
			"Country": "IT",
			"Orders": 61,
			"Total": "$15,080.63"
		},
		"ES": {
			"Country": "ES",
			"Orders": 55,
			"Total": "$11,783.62"
		},
		"JP": {
			"Country": "JP",
			"Orders": 76,
			"Total": "$10,955.18"
		},
		"CZ": {
			"Country": "CZ",
			"Orders": 20,
			"Total": "$2,438.41"
		},
		"CA": {
			"Country": "CA",
			"Orders": 36,
			"Total": "$9,769.85"
		}
	}
}
