$(function() {
	console.log("init");
	var _data = [];

	var countries = d3.selectAll('g');

	$.each(res.GlobalData, function(i, c) {
		_data.push(c);
	});

	$.each(countries[0], function(i, country) {
		$.each(res.GlobalData, function(i, c) {
			cd = i;
			if (country.id === i.toLowerCase()) {
				$("#" + country.id + " path").css("fill", "#8dc63f");
			}
		});
	});
	$("#cz").css("fill", "#8dc63f");
	$("#ch").css("fill", "#8dc63f");
	$("#hu").css("fill", "#8dc63f");
	$("#pl").css("fill", "#8dc63f");
	$("#us *").css("fill", "#8dc63f");



	console.log(_data);
	var DT = $("#tblBlackFriday").dataTable({
		"aaData": _data,
		"aoColumns": [{
			"mData": "Country",
			"bSortable": false,
		}, {
			"mData": "Orders",
			"bSortable": false,
		}, {
			"mData": "Total",
			"bSortable": false,
		}],
		"sDom": "<t>",
		"iDisplayLength": -1,
	});

	$("#tblBlackFriday tbody tr").hover(function(e) {
		var id = e.currentTarget.firstChild.innerHTML.toLowerCase();

		$("#" + id + " path").css("fill", "#f58026");

		$("#" + id).css("fill", "#f58026");

	}, function(e) {
		var id = e.currentTarget.firstChild.innerHTML.toLowerCase();

		$("#" + id + " path").css("fill", "#8dc63f");
		$("#" + id).css("fill", "#8dc63f");
	});
});
